from fastapi import FastAPI
import json

app = FastAPI()

# 加载新华字典数据
with open('word.json', 'r', encoding='utf-8') as f:
    xinhua_data = {item['word']: item['explanation'] for item in json.load(f)}

@app.get("/query/{word}")
async def query(word: str):
    return {
        "新华字典": xinhua_data.get(word, "未找到该字")
    }